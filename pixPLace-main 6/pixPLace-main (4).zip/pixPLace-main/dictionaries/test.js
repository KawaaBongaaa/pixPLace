export const test = {
    hello: "Hello",
    world: "World"
};
