// Config for maintenance mode - SYNCED WITH app_modern.js
MAINTENANCE_MODE: false // MAINTENANCE DISABLED - SYNC WITH app_modern.js
